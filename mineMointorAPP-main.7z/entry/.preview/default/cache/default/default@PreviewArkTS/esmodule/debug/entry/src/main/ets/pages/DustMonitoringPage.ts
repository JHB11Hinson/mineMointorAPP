if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DustMonitoringPage_Params {
    dustList?: DustItem[];
    isLoading?: boolean;
}
import { DustService } from "@normalized:N&&&entry/src/main/ets/model/DustModel&";
import type { DustItem } from "@normalized:N&&&entry/src/main/ets/model/DustModel&";
import { DustMonitorCard } from "@normalized:N&&&entry/src/main/ets/view/dust/DustMonitorCard&";
import promptAction from "@ohos:promptAction";
export class DustMonitoringPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dustList = new ObservedPropertyObjectPU([], this, "dustList");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DustMonitoringPage_Params) {
        if (params.dustList !== undefined) {
            this.dustList = params.dustList;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params: DustMonitoringPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dustList.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dustList.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __dustList: ObservedPropertyObjectPU<DustItem[]>;
    get dustList() {
        return this.__dustList.get();
    }
    set dustList(newValue: DustItem[]) {
        this.__dustList.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    aboutToAppear() {
        this.fetchData();
    }
    // 获取数据的方法
    async fetchData() {
        this.isLoading = true;
        try {
            // 调用静态方法获取灰尘监测数据
            this.dustList = await DustService.getDustList();
        }
        catch (error) {
            console.error('获取灰尘监测数据失败:', error);
            // 错误提示
            promptAction.showToast({
                message: '获取灰尘监测数据失败，请检查网络连接',
                duration: 2000
            });
        }
        finally {
            this.isLoading = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(35:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(37:7)", "entry");
            // 标题栏
            Row.width('100%');
            // 标题栏
            Row.justifyContent(FlexAlign.SpaceBetween);
            // 标题栏
            Row.padding({ left: 16, right: 16, top: 12, bottom: 12 });
            // 标题栏
            Row.backgroundColor(Color.White);
            // 标题栏
            Row.shadow({ radius: 2, color: '#1A000000', offsetX: 0, offsetY: 1 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('灰尘监测数据');
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(38:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('刷新');
            Button.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(43:9)", "entry");
            Button.height(30);
            Button.fontSize(12);
            Button.backgroundColor('#1890FF');
            Button.fontColor(Color.White);
            Button.onClick(() => {
                this.fetchData();
            });
        }, Button);
        Button.pop();
        // 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 统计信息栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(59:7)", "entry");
            // 统计信息栏
            Row.width('100%');
            // 统计信息栏
            Row.height(60);
            // 统计信息栏
            Row.backgroundColor(Color.White);
            // 统计信息栏
            Row.margin({ bottom: 8 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 正常区域数量
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(61:9)", "entry");
            // 正常区域数量
            Column.layoutWeight(1);
            // 正常区域数量
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getNormalAreaCount().toString());
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(62:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#52C41A');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('正常区域');
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(66:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        // 正常区域数量
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 分隔线
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(74:9)", "entry");
            // 分隔线
            Divider.vertical(true);
            // 分隔线
            Divider.height(20);
            // 分隔线
            Divider.color('#E8E8E8');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 警告区域数量
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(80:9)", "entry");
            // 警告区域数量
            Column.layoutWeight(1);
            // 警告区域数量
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getWarningAreaCount().toString());
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(81:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#FAAD14');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('警告区域');
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(85:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        // 警告区域数量
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 分隔线
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(93:9)", "entry");
            // 分隔线
            Divider.vertical(true);
            // 分隔线
            Divider.height(20);
            // 分隔线
            Divider.color('#E8E8E8');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 总区域数量
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(99:9)", "entry");
            // 总区域数量
            Column.layoutWeight(1);
            // 总区域数量
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.dustList.length.toString());
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(100:11)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#1890FF');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('总监测点');
            Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(104:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        // 总区域数量
        Column.pop();
        // 统计信息栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 列表内容
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(118:9)", "entry");
                        Column.height('80%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(119:11)", "entry");
                        LoadingProgress.width(50);
                        LoadingProgress.height(50);
                        LoadingProgress.color('#1890FF');
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在加载监测数据...');
                        Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(123:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#999');
                        Text.margin({ top: 10 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else if (this.dustList.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 无数据时的显示
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(132:9)", "entry");
                        // 无数据时的显示
                        Column.height('80%');
                        // 无数据时的显示
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 使用图形组件代替图片
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(134:11)", "entry");
                        // 使用图形组件代替图片
                        Column.justifyContent(FlexAlign.Center);
                        // 使用图形组件代替图片
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Circle.create();
                        Circle.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(135:13)", "entry");
                        Circle.width(80);
                        Circle.height(80);
                        Circle.fill('#E8E8E8');
                    }, Circle);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('无数据');
                        Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(139:13)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#999');
                        Text.margin({ top: 12 });
                    }, Text);
                    Text.pop();
                    // 使用图形组件代替图片
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('暂无灰尘监测数据');
                        Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(147:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor('#999');
                        Text.margin({ bottom: 8, top: 20 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('请点击刷新按钮或稍后再试');
                        Text.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(151:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#999');
                    }, Text);
                    Text.pop();
                    // 无数据时的显示
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(158:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16 });
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/DustMonitoringPage.ets(160:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new DustMonitorCard(this, { dust: item }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/DustMonitoringPage.ets", line: 161, col: 15 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        dust: item
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                                    dust: item
                                                });
                                            }
                                        }, { name: "DustMonitorCard" });
                                    }
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.dustList, forEachItemGenFunction, (item: DustItem) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    // 获取正常区域数量
    private getNormalAreaCount(): number {
        return this.dustList.filter(item => item.status === 0).length;
    }
    // 获取警告区域数量
    private getWarningAreaCount(): number {
        return this.dustList.filter(item => item.status === 1).length;
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DustMonitoringPage";
    }
}
registerNamedRoute(() => new DustMonitoringPage(undefined, {}), "", { bundleName: "com.example.mineapp", moduleName: "entry", pagePath: "pages/DustMonitoringPage", pageFullPath: "entry/src/main/ets/pages/DustMonitoringPage", integratedHsp: "false", moduleType: "followWithHap" });
