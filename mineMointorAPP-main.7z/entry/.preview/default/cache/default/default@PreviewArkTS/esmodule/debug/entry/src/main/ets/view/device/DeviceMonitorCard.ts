if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DeviceMonitorCard_Params {
    device?: DeviceItem;
}
import { DeviceStatus } from "@normalized:N&&&entry/src/main/ets/model/DeviceModel&";
import type { DeviceItem } from "@normalized:N&&&entry/src/main/ets/model/DeviceModel&";
export class DeviceMonitorCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__device = new SynchedPropertyObjectOneWayPU(params.device, this, "device");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DeviceMonitorCard_Params) {
    }
    updateStateVars(params: DeviceMonitorCard_Params) {
        this.__device.reset(params.device);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__device.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__device.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 接收父组件传来的单条数据，使用 @Prop (单向同步即可，列表一般只需展示)
    private __device: SynchedPropertySimpleOneWayPU<DeviceItem>;
    get device() {
        return this.__device.get();
    }
    set device(newValue: DeviceItem) {
        this.__device.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(10:5)", "entry");
            Row.width('100%');
            Row.height(80);
            Row.backgroundColor(Color.White);
            Row.borderRadius(12);
            Row.padding(10);
            Row.margin({ bottom: 10 });
            Row.shadow({ radius: 4, color: '#1A000000', offsetX: 0, offsetY: 2 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左侧：图标与状态
            Column.create();
            Column.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(12:7)", "entry");
            // 左侧：图标与状态
            Column.width('15%');
            // 左侧：图标与状态
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 根据状态动态改变图标颜色
            Image.create(this.getIconResource(this.device.status));
            Image.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(14:9)", "entry");
            // 根据状态动态改变图标颜色
            Image.width(40);
            // 根据状态动态改变图标颜色
            Image.height(40);
            // 根据状态动态改变图标颜色
            Image.objectFit(ImageFit.Contain);
            // 根据状态动态改变图标颜色
            Image.fillColor(this.getStatusColor(this.device.status));
        }, Image);
        // 左侧：图标与状态
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 中间：核心数据
            Column.create();
            Column.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(25:7)", "entry");
            // 中间：核心数据
            Column.width('60%');
            // 中间：核心数据
            Column.alignItems(HorizontalAlign.Start);
            // 中间：核心数据
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.device.name);
            Text.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(26:9)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#333');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(31:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`当前值: ${this.device.value} ${this.device.unit}`);
            Text.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(32:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ top: 4 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 阈值提示
            Text.create(`(阈值: ${this.device.threshold})`);
            Text.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(38:11)", "entry");
            // 阈值提示
            Text.fontSize(12);
            // 阈值提示
            Text.fontColor('#999');
            // 阈值提示
            Text.margin({ left: 5, top: 4 });
        }, Text);
        // 阈值提示
        Text.pop();
        Row.pop();
        // 中间：核心数据
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 右侧：位置与时间
            Column.create();
            Column.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(49:7)", "entry");
            // 右侧：位置与时间
            Column.width('25%');
            // 右侧：位置与时间
            Column.alignItems(HorizontalAlign.End);
            // 右侧：位置与时间
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.device.location);
            Text.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(50:9)", "entry");
            Text.fontSize(12);
            Text.fontColor({ "id": 125830976, "type": 10001, params: [], "bundleName": "com.example.mineapp", "moduleName": "entry" });
            Text.backgroundColor('#E6F2FF');
            Text.padding({ left: 6, right: 6, top: 2, bottom: 2 });
            Text.borderRadius(4);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.device.updateTime);
            Text.debugLine("entry/src/main/ets/view/device/DeviceMonitorCard.ets(57:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999');
            Text.margin({ top: 8 });
        }, Text);
        Text.pop();
        // 右侧：位置与时间
        Column.pop();
        Row.pop();
    }
    // 辅助函数：根据状态返回颜色
    private getStatusColor(status: DeviceStatus): string {
        if (status === DeviceStatus.DANGER)
            return '#FF4D4F'; // 红
        if (status === DeviceStatus.WARNING)
            return '#FAAD14'; // 黄
        return '#52C41A'; // 绿
    }
    private getIconResource(_status: DeviceStatus): Resource {
        return { "id": 125830212, "type": 20000, params: [], "bundleName": "com.example.mineapp", "moduleName": "entry" };
    }
    rerender() {
        this.updateDirtyElements();
    }
}
