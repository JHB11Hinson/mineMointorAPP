if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DeviceMonitoringPage_Params {
    deviceList?: DeviceItem[];
    isLoading?: boolean;
}
import { DeviceService } from "@normalized:N&&&entry/src/main/ets/model/DeviceModel&";
import type { DeviceItem } from "@normalized:N&&&entry/src/main/ets/model/DeviceModel&";
import { DeviceMonitorCard } from "@normalized:N&&&entry/src/main/ets/view/device/DeviceMonitorCard&";
import promptAction from "@ohos:promptAction";
export class DeviceMonitoringPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__deviceList = new ObservedPropertyObjectPU([], this, "deviceList");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DeviceMonitoringPage_Params) {
        if (params.deviceList !== undefined) {
            this.deviceList = params.deviceList;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params: DeviceMonitoringPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__deviceList.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__deviceList.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __deviceList: ObservedPropertyObjectPU<DeviceItem[]>;
    get deviceList() {
        return this.__deviceList.get();
    }
    set deviceList(newValue: DeviceItem[]) {
        this.__deviceList.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    aboutToAppear() {
        this.fetchData();
    }
    // 获取数据的方法
    async fetchData() {
        this.isLoading = true;
        try {
            // 调用静态方法获取数据，现在的 request 已经是真的网络请求了
            // 这里的 await 会等待 HttpUtil.get 返回结果
            this.deviceList = await DeviceService.getDeviceList();
        }
        catch (error) {
            console.error('获取设备列表失败:', error);
            // 简单的错误提示
            promptAction.showToast({
                message: '网络请求失败，请检查 json-server 是否启动及 IP 配置',
                duration: 2000
            });
        }
        finally {
            this.isLoading = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(37:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor({ "id": 125833705, "type": 10001, params: [], "bundleName": "com.example.mineapp", "moduleName": "entry" });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(39:7)", "entry");
            // 标题栏
            Row.width('100%');
            // 标题栏
            Row.justifyContent(FlexAlign.SpaceBetween);
            // 标题栏
            Row.padding(16);
            // 标题栏
            Row.backgroundColor({ "id": 125833705, "type": 10001, params: [], "bundleName": "com.example.mineapp", "moduleName": "entry" });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('设备实时监控');
            Text.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(40:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('刷新');
            Button.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(44:9)", "entry");
            Button.height(30);
            Button.fontSize(12);
            Button.onClick(() => {
                this.fetchData();
            });
        }, Button);
        Button.pop();
        // 标题栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 列表内容
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(58:9)", "entry");
                        Column.height('80%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(59:11)", "entry");
                        LoadingProgress.width(50);
                        LoadingProgress.height(50);
                        LoadingProgress.color(Color.Blue);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在请求 Mock 数据...');
                        Text.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(60:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#999');
                        Text.margin({ top: 10 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(65:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding({ left: 16, right: 16, top: 10 });
                        List.scrollBar(BarState.Off);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/DeviceMonitoringPage.ets(67:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new 
                                                // 这里的组件代码复用之前的，不需要改
                                                DeviceMonitorCard(this, { device: item }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/DeviceMonitoringPage.ets", line: 69, col: 15 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        device: item
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                                    device: item
                                                });
                                            }
                                        }, { name: "DeviceMonitorCard" });
                                    }
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.deviceList, forEachItemGenFunction, (item: DeviceItem) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DeviceMonitoringPage";
    }
}
registerNamedRoute(() => new DeviceMonitoringPage(undefined, {}), "", { bundleName: "com.example.mineapp", moduleName: "entry", pagePath: "pages/DeviceMonitoringPage", pageFullPath: "entry/src/main/ets/pages/DeviceMonitoringPage", integratedHsp: "false", moduleType: "followWithHap" });
