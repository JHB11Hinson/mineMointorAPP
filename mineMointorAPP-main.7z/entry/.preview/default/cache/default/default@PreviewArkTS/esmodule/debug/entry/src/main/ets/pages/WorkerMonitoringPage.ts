if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WorkerMonitoringPage_Params {
    workerList?: WorkerItem[];
    isLoading?: boolean;
    totalWorkers?: number;
    dangerCount?: number;
}
import { WorkerService } from "@normalized:N&&&entry/src/main/ets/model/WorkerModel&";
import type { WorkerItem } from "@normalized:N&&&entry/src/main/ets/model/WorkerModel&";
import { WorkerListCard } from "@normalized:N&&&entry/src/main/ets/view/worker/WorkerListCard&";
import promptAction from "@ohos:promptAction";
export class WorkerMonitoringPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__workerList = new ObservedPropertyObjectPU([], this, "workerList");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__totalWorkers = new ObservedPropertySimplePU(0, this, "totalWorkers");
        this.__dangerCount = new ObservedPropertySimplePU(0, this, "dangerCount");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WorkerMonitoringPage_Params) {
        if (params.workerList !== undefined) {
            this.workerList = params.workerList;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.totalWorkers !== undefined) {
            this.totalWorkers = params.totalWorkers;
        }
        if (params.dangerCount !== undefined) {
            this.dangerCount = params.dangerCount;
        }
    }
    updateStateVars(params: WorkerMonitoringPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__workerList.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__totalWorkers.purgeDependencyOnElmtId(rmElmtId);
        this.__dangerCount.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__workerList.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__totalWorkers.aboutToBeDeleted();
        this.__dangerCount.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 定义状态变量
    private __workerList: ObservedPropertyObjectPU<WorkerItem[]>;
    get workerList() {
        return this.__workerList.get();
    }
    set workerList(newValue: WorkerItem[]) {
        this.__workerList.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    // 统计数据 (用于页面顶部展示)
    private __totalWorkers: ObservedPropertySimplePU<number>;
    get totalWorkers() {
        return this.__totalWorkers.get();
    }
    set totalWorkers(newValue: number) {
        this.__totalWorkers.set(newValue);
    }
    private __dangerCount: ObservedPropertySimplePU<number>;
    get dangerCount() {
        return this.__dangerCount.get();
    }
    set dangerCount(newValue: number) {
        this.__dangerCount.set(newValue);
    }
    // 组件挂载时获取数据
    aboutToAppear() {
        this.fetchData();
    }
    async fetchData() {
        this.isLoading = true;
        try {
            // 1. 发起网络请求
            const data = await WorkerService.getWorkerList();
            this.workerList = data;
            // 2. 简单的本地计算：统计总人数和危险人数
            this.totalWorkers = this.workerList.length;
            this.dangerCount = this.workerList.filter(w => w.status === 2).length;
        }
        catch (error) {
            console.error('Fetch worker error:', error);
            promptAction.showToast({ message: '获取工人数据失败', duration: 2000 });
        }
        finally {
            this.isLoading = false;
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(40:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F3F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 1. 顶部标题栏 (带简单的统计信息)
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(42:7)", "entry");
            // 1. 顶部标题栏 (带简单的统计信息)
            Column.padding(16);
            // 1. 顶部标题栏 (带简单的统计信息)
            Column.backgroundColor(Color.White);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('人员安全监控');
            Text.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(43:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.width('100%');
            Text.textAlign(TextAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 统计摘要条
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(50:9)", "entry");
            // 统计摘要条
            Row.width('100%');
            // 统计摘要条
            Row.margin({ top: 10 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`当前井下作业: ${this.totalWorkers} 人`);
            Text.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(51:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(55:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.dangerCount > 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(58:13)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 125830212, "type": 20000, params: [], "bundleName": "com.example.mineapp", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(59:15)", "entry");
                        Image.width(16);
                        Image.height(16);
                        Image.fillColor('#FF4D4F');
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(` ${this.dangerCount} 人高危预警`);
                        Text.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(63:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#FF4D4F');
                        Text.fontWeight(FontWeight.Bold);
                    }, Text);
                    Text.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('全员安全');
                        Text.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(69:13)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#52C41A');
                    }, Text);
                    Text.pop();
                });
            }
        }, If);
        If.pop();
        // 统计摘要条
        Row.pop();
        // 1. 顶部标题栏 (带简单的统计信息)
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 分割线
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(81:7)", "entry");
            // 分割线
            Divider.strokeWidth(1);
            // 分割线
            Divider.color('#E3E3E3');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 2. 列表内容区域
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(85:9)", "entry");
                        Column.height('80%');
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(86:11)", "entry");
                        LoadingProgress.width(40);
                        LoadingProgress.height(40);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('正在同步人员定位...');
                        Text.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(87:11)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#999');
                        Text.margin({ top: 10 });
                    }, Text);
                    Text.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        List.create();
                        List.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(92:9)", "entry");
                        List.width('100%');
                        List.layoutWeight(1);
                        List.padding(16);
                    }, List);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            {
                                const itemCreation = (elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    ListItem.create(deepRenderFunction, true);
                                    if (!isInitialRender) {
                                        ListItem.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                };
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    ListItem.create(deepRenderFunction, true);
                                    ListItem.debugLine("entry/src/main/ets/pages/WorkerMonitoringPage.ets(94:13)", "entry");
                                };
                                const deepRenderFunction = (elmtId, isInitialRender) => {
                                    itemCreation(elmtId, isInitialRender);
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new WorkerListCard(this, { worker: item }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/WorkerMonitoringPage.ets", line: 95, col: 15 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {
                                                        worker: item
                                                    };
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {
                                                    worker: item
                                                });
                                            }
                                        }, { name: "WorkerListCard" });
                                    }
                                    ListItem.pop();
                                };
                                this.observeComponentCreation2(itemCreation2, ListItem);
                                ListItem.pop();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.workerList, forEachItemGenFunction, (item: WorkerItem) => item.id.toString(), false, false);
                    }, ForEach);
                    ForEach.pop();
                    List.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
