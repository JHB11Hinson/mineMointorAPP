if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    currentIndex?: number;
    tabsController?: TabsController;
}
import { TabListData } from "@normalized:N&&&entry/src/main/ets/viewmodel/TabItemData&";
import type { TabItemInterface } from "@normalized:N&&&entry/src/main/ets/viewmodel/TabItemData&";
import { DeviceMonitoringPage } from "@normalized:N&&&entry/src/main/ets/pages/DeviceMonitoringPage&";
import { DustMonitoringPage } from "@normalized:N&&&entry/src/main/ets/pages/DustMonitoringPage&";
import { WorkerMonitoringPage } from "@normalized:N&&&entry/src/main/ets/pages/WorkerMonitoringPage&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentIndex = new ObservedPropertySimplePU(0, this, "currentIndex");
        this.tabsController = new TabsController();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.currentIndex !== undefined) {
            this.currentIndex = params.currentIndex;
        }
        if (params.tabsController !== undefined) {
            this.tabsController = params.tabsController;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 当前选中的 Tab 索引
    private __currentIndex: ObservedPropertySimplePU<number>;
    get currentIndex() {
        return this.__currentIndex.get();
    }
    set currentIndex(newValue: number) {
        this.__currentIndex.set(newValue);
    }
    // 控制 Tabs 切换的控制器
    private tabsController: TabsController;
    // 自定义 TabBar 的构建函数
    TabBuilder(item: TabItemInterface, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(16:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.White);
            Column.onClick(() => {
                this.currentIndex = item.index;
                this.tabsController.changeIndex(item.index);
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/Index.ets(17:7)", "entry");
            Divider.strokeWidth(0.5);
            Divider.color('#E3E3E3');
            Divider.width('100%');
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(22:7)", "entry");
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.currentIndex === item.index ? item.imageActivated : item.imageOriginal);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(23:9)", "entry");
            Context.animation({ duration: 300, curve: Curve.EaseOut });
            Image.width(24);
            Image.height(24);
            Image.objectFit(ImageFit.Contain);
            Image.fillColor(this.currentIndex === item.index ? '#007DFF' : '#999999');
            Image.margin({ bottom: 4 });
            Image.scale({
                x: this.currentIndex === item.index ? 1.2 : 1.0,
                y: this.currentIndex === item.index ? 1.2 : 1.0
            });
            Context.animation(null);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(35:9)", "entry");
            Context.animation({ duration: 300 });
            Text.fontColor(this.currentIndex === item.index ? '#007DFF' : '#999999');
            Text.fontSize(10);
            Text.fontWeight(this.currentIndex === item.index ? 500 : 400);
            Context.animation(null);
        }, Text);
        Text.pop();
        Column.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // BarPosition.End
            Tabs.create({ barPosition: BarPosition.End, controller: this.tabsController });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(55:5)", "entry");
            // BarPosition.End
            Tabs.scrollable(true);
            // BarPosition.End
            Tabs.barMode(BarMode.Fixed);
            // BarPosition.End
            Tabs.onChange((index: number) => {
                // 监听滑动事件，同步更新 currentIndex，触发 UI 动效
                this.currentIndex = index;
            });
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new DeviceMonitoringPage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 59, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "DeviceMonitoringPage" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, TabListData[0]);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(58:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new DustMonitoringPage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 65, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "DustMonitoringPage" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, TabListData[1]);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(64:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new WorkerMonitoringPage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 71, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "WorkerMonitoringPage" });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, TabListData[2]);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(70:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create();
                    Column.debugLine("entry/src/main/ets/pages/Index.ets(77:9)", "entry");
                    Column.justifyContent(FlexAlign.Center);
                    Column.width('100%');
                    Column.height('100%');
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create("设置页面");
                    Text.debugLine("entry/src/main/ets/pages/Index.ets(78:11)", "entry");
                    Text.fontSize(30);
                }, Text);
                Text.pop();
                Column.pop();
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder.call(this, TabListData[3]);
                } });
            TabContent.debugLine("entry/src/main/ets/pages/Index.ets(76:7)", "entry");
        }, TabContent);
        TabContent.pop();
        // BarPosition.End
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.mineapp", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
