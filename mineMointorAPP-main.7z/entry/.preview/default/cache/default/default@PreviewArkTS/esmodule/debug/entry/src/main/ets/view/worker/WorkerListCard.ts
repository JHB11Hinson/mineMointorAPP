if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface WorkerListCard_Params {
    worker?: WorkerItem;
}
import { WorkerStatus } from "@normalized:N&&&entry/src/main/ets/model/WorkerModel&";
import type { WorkerItem } from "@normalized:N&&&entry/src/main/ets/model/WorkerModel&";
export class WorkerListCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__worker = new SynchedPropertyObjectOneWayPU(params.worker, this, "worker");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: WorkerListCard_Params) {
    }
    updateStateVars(params: WorkerListCard_Params) {
        this.__worker.reset(params.worker);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__worker.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__worker.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 接收父组件传递的单条工人数据
    private __worker: SynchedPropertySimpleOneWayPU<WorkerItem>;
    get worker() {
        return this.__worker.get();
    }
    set worker(newValue: WorkerItem) {
        this.__worker.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(9:5)", "entry");
            Row.width('100%');
            Row.height(100);
            Row.backgroundColor(Color.White);
            Row.borderRadius(12);
            Row.padding(12);
            Row.margin({ bottom: 12 });
            Row.shadow(this.worker.status === WorkerStatus.DANGER ?
                { radius: 8, color: '#4DFF4D4F', offsetX: 0, offsetY: 2 } :
                { radius: 4, color: '#1A000000', offsetX: 0, offsetY: 2 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 1. 左侧：头像与岗位
            Column.create();
            Column.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(11:7)", "entry");
            // 1. 左侧：头像与岗位
            Column.width('20%');
            // 1. 左侧：头像与岗位
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 实际项目可用 Image 组件
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(13:9)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create({ width: 50, height: 50 });
            Circle.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(14:11)", "entry");
            Circle.fill(this.getAvatarColor(this.worker.status));
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.worker.name.substring(0, 1));
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(17:11)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.White);
        }, Text);
        Text.pop();
        // 实际项目可用 Image 组件
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.worker.role);
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(23:9)", "entry");
            Text.fontSize(12);
            Text.fontColor('#666');
            Text.margin({ top: 6 });
            Text.padding({ left: 8, right: 8, top: 2, bottom: 2 });
            Text.backgroundColor('#F0F0F0');
            Text.borderRadius(10);
        }, Text);
        Text.pop();
        // 1. 左侧：头像与岗位
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 2. 中间：详细信息
            Column.create();
            Column.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(35:7)", "entry");
            // 2. 中间：详细信息
            Column.width('50%');
            // 2. 中间：详细信息
            Column.alignItems(HorizontalAlign.Start);
            // 2. 中间：详细信息
            Column.justifyContent(FlexAlign.Center);
            // 2. 中间：详细信息
            Column.padding({ left: 10 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.worker.name);
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(36:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor('#333');
            Text.margin({ bottom: 8 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(42:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 125830173, "type": 20000, params: [], "bundleName": "com.example.mineapp", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(43:11)", "entry");
            Image.width(14);
            Image.height(14);
            Image.fillColor('#999');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.worker.location);
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(47:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#666');
            Text.margin({ left: 4 });
        }, Text);
        Text.pop();
        Row.pop();
        // 2. 中间：详细信息
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 3. 右侧：生命体征 (心率)
            Column.create();
            Column.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(59:7)", "entry");
            // 3. 右侧：生命体征 (心率)
            Column.width('30%');
            // 3. 右侧：生命体征 (心率)
            Column.alignItems(HorizontalAlign.End);
            // 3. 右侧：生命体征 (心率)
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(60:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.worker.heartRate.toString());
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(61:11)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.worker.status === WorkerStatus.DANGER ? '#FF4D4F' : '#007DFF');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('bpm');
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(67:11)", "entry");
            Text.fontSize(12);
            Text.fontColor('#999');
            Text.margin({ left: 4, top: 8 });
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 状态标签
            Text.create(this.getStatusText(this.worker.status));
            Text.debugLine("entry/src/main/ets/view/worker/WorkerListCard.ets(74:9)", "entry");
            // 状态标签
            Text.fontSize(12);
            // 状态标签
            Text.fontColor(this.getStatusColor(this.worker.status));
            // 状态标签
            Text.padding({ left: 8, right: 8, top: 4, bottom: 4 });
            // 状态标签
            Text.backgroundColor(this.getStatusBgColor(this.worker.status));
            // 状态标签
            Text.borderRadius(4);
            // 状态标签
            Text.margin({ top: 6 });
        }, Text);
        // 状态标签
        Text.pop();
        // 3. 右侧：生命体征 (心率)
        Column.pop();
        Row.pop();
    }
    // --- 辅助样式函数 ---
    private getAvatarColor(status: WorkerStatus): string {
        if (status === WorkerStatus.DANGER)
            return '#FF4D4F';
        if (status === WorkerStatus.FATIGUE)
            return '#FAAD14';
        return '#007DFF'; // 正常蓝色
    }
    private getStatusText(status: WorkerStatus): string {
        switch (status) {
            case WorkerStatus.DANGER: return '高危预警';
            case WorkerStatus.FATIGUE: return '疲劳作业';
            default: return '状态良好';
        }
    }
    private getStatusColor(status: WorkerStatus): string {
        if (status === WorkerStatus.DANGER)
            return '#FF4D4F';
        if (status === WorkerStatus.FATIGUE)
            return '#FAAD14';
        return '#52C41A';
    }
    private getStatusBgColor(status: WorkerStatus): string {
        if (status === WorkerStatus.DANGER)
            return '#FFF1F0';
        if (status === WorkerStatus.FATIGUE)
            return '#FFFBE6';
        return '#F6FFED';
    }
    rerender() {
        this.updateDirtyElements();
    }
}
