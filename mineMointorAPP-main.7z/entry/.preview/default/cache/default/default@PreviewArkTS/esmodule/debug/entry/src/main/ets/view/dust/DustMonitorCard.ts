if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DustMonitorCard_Params {
    dust?: DustItem;
}
import { DustStatus } from "@normalized:N&&&entry/src/main/ets/model/DustModel&";
import type { DustItem } from "@normalized:N&&&entry/src/main/ets/model/DustModel&";
export class DustMonitorCard extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__dust = new SynchedPropertyObjectOneWayPU(params.dust, this, "dust");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DustMonitorCard_Params) {
    }
    updateStateVars(params: DustMonitorCard_Params) {
        this.__dust.reset(params.dust);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dust.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dust.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 接收父组件传来的单条数据
    private __dust: SynchedPropertySimpleOneWayPU<DustItem>;
    get dust() {
        return this.__dust.get();
    }
    set dust(newValue: DustItem) {
        this.__dust.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(9:5)", "entry");
            Row.width('100%');
            Row.height(80);
            Row.backgroundColor(Color.White);
            Row.borderRadius(12);
            Row.padding(10);
            Row.margin({ bottom: 10 });
            Row.shadow({ radius: 4, color: '#1A000000', offsetX: 0, offsetY: 2 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左侧：自定义图标区域
            Column.create();
            Column.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(11:7)", "entry");
            // 左侧：自定义图标区域
            Column.width('15%');
            // 左侧：自定义图标区域
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 使用Circle组件创建圆形图标，代替图片
            Stack.create();
            Stack.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(13:9)", "entry");
            // 使用Circle组件创建圆形图标，代替图片
            Stack.width(40);
            // 使用Circle组件创建圆形图标，代替图片
            Stack.height(40);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 外圈圆形
            Circle.create();
            Circle.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(15:11)", "entry");
            // 外圈圆形
            Circle.width(36);
            // 外圈圆形
            Circle.height(36);
            // 外圈圆形
            Circle.fill(this.getStatusColor(this.dust.status));
            // 外圈圆形
            Circle.opacity(0.2);
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 内圈圆形
            Circle.create();
            Circle.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(22:11)", "entry");
            // 内圈圆形
            Circle.width(24);
            // 内圈圆形
            Circle.height(24);
            // 内圈圆形
            Circle.fill(this.getStatusColor(this.dust.status));
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图标中间的文本
            Text.create(this.getIconText(this.dust.status));
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(28:11)", "entry");
            // 图标中间的文本
            Text.fontSize(12);
            // 图标中间的文本
            Text.fontColor(Color.White);
            // 图标中间的文本
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        // 图标中间的文本
        Text.pop();
        // 使用Circle组件创建圆形图标，代替图片
        Stack.pop();
        // 左侧：自定义图标区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 中间：核心数据 - 区域和PM值
            Column.create();
            Column.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(40:7)", "entry");
            // 中间：核心数据 - 区域和PM值
            Column.width('60%');
            // 中间：核心数据 - 区域和PM值
            Column.alignItems(HorizontalAlign.Start);
            // 中间：核心数据 - 区域和PM值
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 区域名称
            Text.create(this.dust.area);
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(42:9)", "entry");
            // 区域名称
            Text.fontSize(16);
            // 区域名称
            Text.fontWeight(FontWeight.Bold);
            // 区域名称
            Text.fontColor('#333');
        }, Text);
        // 区域名称
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // PM2.5 和 PM10 数值
            Row.create();
            Row.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(48:9)", "entry");
            // PM2.5 和 PM10 数值
            Row.margin({ top: 4 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // PM2.5
            Column.create();
            Column.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(50:11)", "entry");
            // PM2.5
            Column.margin({ right: 16 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('PM2.5');
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(51:13)", "entry");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.dust.pm25}`);
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(54:13)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.getPm25Color(this.dust.pm25));
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        // PM2.5
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 分隔线
            Divider.create();
            Divider.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(62:11)", "entry");
            // 分隔线
            Divider.vertical(true);
            // 分隔线
            Divider.height(20);
            // 分隔线
            Divider.color('#E0E0E0');
            // 分隔线
            Divider.margin({ right: 16 });
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // PM10
            Column.create();
            Column.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(69:11)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('PM10');
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(70:13)", "entry");
            Text.fontSize(12);
            Text.fontColor('#666');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.dust.pm10}`);
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(73:13)", "entry");
            Text.fontSize(16);
            Text.fontColor(this.getPm10Color(this.dust.pm10));
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        // PM10
        Column.pop();
        // PM2.5 和 PM10 数值
        Row.pop();
        // 中间：核心数据 - 区域和PM值
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 右侧：状态标签
            Column.create();
            Column.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(86:7)", "entry");
            // 右侧：状态标签
            Column.width('25%');
            // 右侧：状态标签
            Column.alignItems(HorizontalAlign.End);
            // 右侧：状态标签
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 状态标签
            Row.create();
            Row.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(88:9)", "entry");
            // 状态标签
            Row.padding({ left: 8, right: 8, top: 4, bottom: 4 });
            // 状态标签
            Row.border({
                width: 1,
                color: this.getStatusColor(this.dust.status),
                radius: 12
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 状态指示圆点
            Circle.create();
            Circle.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(90:11)", "entry");
            // 状态指示圆点
            Circle.width(6);
            // 状态指示圆点
            Circle.height(6);
            // 状态指示圆点
            Circle.fill(this.getStatusColor(this.dust.status));
            // 状态指示圆点
            Circle.margin({ right: 4 });
        }, Circle);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.getStatusText(this.dust.status));
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(96:11)", "entry");
            Text.fontSize(14);
            Text.fontColor(this.getStatusColor(this.dust.status));
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        // 状态标签
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 空气质量提示
            Text.create(this.getAirQualityHint(this.dust.pm25, this.dust.pm10));
            Text.debugLine("entry/src/main/ets/view/dust/DustMonitorCard.ets(109:9)", "entry");
            // 空气质量提示
            Text.fontSize(11);
            // 空气质量提示
            Text.fontColor('#999');
            // 空气质量提示
            Text.margin({ top: 6 });
            // 空气质量提示
            Text.maxLines(1);
        }, Text);
        // 空气质量提示
        Text.pop();
        // 右侧：状态标签
        Column.pop();
        Row.pop();
    }
    // 辅助函数：根据状态返回图标中的文字
    private getIconText(status: DustStatus): string {
        if (status === DustStatus.WARNING)
            return '!';
        return '✔'; // 表示"空气"
    }
    // 辅助函数：根据状态返回颜色
    private getStatusColor(status: DustStatus): string {
        if (status === DustStatus.WARNING)
            return '#FAAD14'; // 黄色警告
        return '#52C41A'; // 绿色正常
    }
    // 辅助函数：根据状态返回文本
    private getStatusText(status: DustStatus): string {
        if (status === DustStatus.WARNING)
            return '警告';
        return '正常';
    }
    // 辅助函数：根据PM2.5值返回颜色
    private getPm25Color(pm25: number): string {
        if (pm25 > 150)
            return '#FF4D4F'; // 红色：重度污染
        if (pm25 > 75)
            return '#FAAD14'; // 黄色：中度污染
        if (pm25 > 35)
            return '#FADB14'; // 浅黄色：轻度污染
        return '#52C41A'; // 绿色：良好
    }
    // 辅助函数：根据PM10值返回颜色
    private getPm10Color(pm10: number): string {
        if (pm10 > 200)
            return '#FF4D4F'; // 红色：重度污染
        if (pm10 > 150)
            return '#FAAD14'; // 黄色：中度污染
        if (pm10 > 50)
            return '#FADB14'; // 浅黄色：轻度污染
        return '#52C41A'; // 绿色：良好
    }
    // 辅助函数：根据PM值返回空气质量提示
    private getAirQualityHint(pm25: number, pm10: number): string {
        const maxPm = Math.max(pm25, pm10);
        if (maxPm > 150)
            return '空气污染严重';
        if (maxPm > 75)
            return '空气轻度污染';
        return '空气质量良好';
    }
    rerender() {
        this.updateDirtyElements();
    }
}
